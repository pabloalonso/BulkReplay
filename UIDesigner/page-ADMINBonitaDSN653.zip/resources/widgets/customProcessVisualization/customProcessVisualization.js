(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customProcessVisualization', function() {
    return {
      controllerAs: 'ctrl',
      controller: function processVisuController ($scope, $element, $interval, $http) {
    var iframe = $element.find('iframe')[0];
    var ctrl = this;
    $http.get('/'+$scope.properties.appName+'/API/bpm/case/'+$scope.properties.caseId).
    success(function(data){
        ctrl.src = "/bonita/portal.js/#/admin/monitoring/"+data.processDefinitionId+"-"+
        ($scope.properties.type==="case"?$scope.properties.caseId:"")+"?diagramOnly=1";
    })
    
    var polling = $interval(function() {
        iframe.style.height = (iframe.contentWindow.document.body.scrollHeight || 400) + "px";
    }, 100);
    
    $scope.$on('$destroy', function() {
        $interval.cancel(polling);
    });
},
      template: '<iframe width="100%" style="border: 0" scrolling="no" ng-src="{{ctrl.src}}"></iframe>'
    };
  });
